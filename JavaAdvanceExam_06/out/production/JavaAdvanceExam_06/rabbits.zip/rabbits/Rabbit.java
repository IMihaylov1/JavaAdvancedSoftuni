package rabbits;

public class Rabbit {
    private String name;
    private String species;

    public String getName() {
        return this.name;
    }

    public String getSpecies() {
        return this.species;
    }

    private boolean available;

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public Rabbit(String name, String species) {
        this.name = name;
        this.species = species;
        this.available = true;
    }
    public boolean isAvailable(){
        return this.available;
    }

    @Override
    public String toString() {
        return String.format("Rabbit (%s): %s",this.species,this.name);
    }
}
